<?php
include 'dbconnect.php';

$user_id = $_GET['user_id'] ?? '';  

if (empty($user_id)) {
    echo json_encode(['status' => 'error', 'message' => 'User ID tidak ditemukan.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = "
        SELECT 
            pengajuancuti.id, 
            tipecuti.nama_tipe, 
            pengajuancuti.jumlah,
            pengajuancuti.tanggal_mulai, 
            pengajuancuti.tanggal_selesai 
        FROM pengajuancuti 
        JOIN tipecuti ON pengajuancuti.tipe_id = tipecuti.id 
        WHERE pengajuancuti.user_id = $user_id 
        ORDER BY pengajuancuti.tanggal_mulai ASC
    ";

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $riwayatCuti = [];
        while ($row = $result->fetch_assoc()) {
            $riwayatCuti[] = $row;
        }
        echo json_encode($riwayatCuti);
    } else {
        echo json_encode([]); 
    }
}

$conn->close();
?>
