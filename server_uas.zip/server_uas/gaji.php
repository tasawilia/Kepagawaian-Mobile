<?php
include_once 'dbconnect.php';

$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : null;
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : null;

if ($bulan && $tahun) {
    $stat = $conn->prepare("SELECT id, periode_bulan, periode_tahun, gaji_pokok, tunjangan, potongan, gaji_bersih FROM gaji WHERE periode_bulan = ? AND periode_tahun = ?");
    $stat->bind_param("ii", $bulan, $tahun);
} else {
    $stat = $conn->prepare("SELECT id, periode_bulan, periode_tahun, gaji_pokok, tunjangan, potongan, gaji_bersih FROM gaji");
}

$stat->execute();
$stat->bind_result($id,  $periode_bulan, $periode_tahun, $gaji_pokok, $tunjangan, $potongan, $gaji_bersih);

$arrayproduct = array();

while ($stat->fetch()) {
    $data = array();
    $data['id'] = $id;
    $data['periode_bulan'] = $periode_bulan;
    $data['periode_tahun'] = $periode_tahun;
    $data['gaji_pokok'] = $gaji_pokok;
    $data['tunjangan'] = $tunjangan;
    $data['potongan'] = $potongan;
    $data['gaji_bersih'] = $gaji_bersih;

    array_push($arrayproduct, $data);
}

echo json_encode($arrayproduct);
?>
