<?php
include 'dbconnect.php';

$email = $_POST['email'];
$nama = $_POST['nama'];
$password = $_POST['password'];
$nik = $_POST['nik'];
$alamat = $_POST['alamat'];


if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['pesan' => 'Format email tidak valid']);
    exit;
}


$data = mysqli_query($conn, "INSERT INTO user (email, nama, password) VALUES ('$email', '$nama', '$password')");

if ($data) {
    $id = mysqli_insert_id($conn);

    $dataKaryawan = mysqli_query($conn, "INSERT INTO karyawan (id, nama, nik, alamat) VALUES ('$id', '$nama', '$nik', '$alamat')");
    if ($dataKaryawan) {
        echo json_encode(['pesan' => 'Registrasi berhasil']);
    } else {
        echo json_encode(['pesan' => 'Gagal menyimpan data karyawan']);
    }
} else {
    echo json_encode(['pesan' => 'Gagal menyimpan data pengguna']);
}
?>
