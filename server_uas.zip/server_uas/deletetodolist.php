<?php
include_once 'dbconnect.php';

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data["id"])) {
    $id = $data["id"];
} else {
    echo json_encode(["success" => false, "error" => "ID tidak diberikan"]);
    return;
}

$query = "DELETE FROM todolist WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id); 

$execute = $stmt->execute();

$arrproduct = [];
if ($execute) {
    $arrproduct["success"] = true;
} else {
    $arrproduct["success"] = false;
    $arrproduct["error"] = $stmt->error;
}

header('Content-Type: application/json');
echo json_encode($arrproduct);
?>
