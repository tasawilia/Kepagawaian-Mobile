<?php
include 'dbconnect.php';

$tanggal_mulai = $_POST['tanggal_mulai'];
$tanggal_selesai = $_POST['tanggal_selesai'];
$tipe_id = $_POST['tipe_cuti'];  
$jumlah = $_POST['jumlah'];
$user_id = $_POST['user_id'];  

$tanggal_mulai = $conn->real_escape_string($tanggal_mulai);
$tanggal_selesai = $conn->real_escape_string($tanggal_selesai);
$tipe_id = $conn->real_escape_string($tipe_id);
$jumlah = $conn->real_escape_string($jumlah);
$user_id = $conn->real_escape_string($user_id);

$sql = "INSERT INTO pengajuancuti (tipe_id, tanggal_mulai, tanggal_selesai, jumlah, user_id) 
        VALUES ($tipe_id, '$tanggal_mulai', '$tanggal_selesai', $jumlah, $user_id)";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['status' => 'success', 'message' => 'Pengajuan cuti berhasil']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Pengajuan cuti gagal']);
}

$conn->close();
?>
