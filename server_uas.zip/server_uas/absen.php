<?php
include_once 'dbconnect.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['user_id']) && isset($data['tanggal']) && isset($data['status']) && isset($data['tipe'])) {
        $user_id = $data['user_id']; 
        $tanggal = $data['tanggal'];
        $status = $data['status'];
        $tipe = $data['tipe'];
        $waktu = isset($data['waktu']) && !empty($data['waktu']) ? $data['waktu'] : null;
        $created_at = date('Y-m-d H:i:s');
        $updated_at = date('Y-m-d H:i:s');

        if ($user_id == '0') {
            echo json_encode(['message' => 'User ID tidak valid']);
            exit();
        }

        $query = "INSERT INTO absensi (tanggal, waktu, status, tipe, user_id, created_at, updated_at)
                  VALUES (?, ?, ?, ?, ?, ?, ?)";

        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('sssssss', $tanggal, $waktu, $status, $tipe, $user_id, $created_at, $updated_at);

            if ($stmt->execute()) {
                echo json_encode(['message' => 'Absensi berhasil disimpan']);
            } else {
                echo json_encode(['message' => 'Gagal menyimpan absensi']);
            }

            $stmt->close();
        } else {
            echo json_encode(['message' => 'Terjadi kesalahan dalam query']);
        }
    } else {
        echo json_encode(['message' => 'Data tidak lengkap']);
    }

    $conn->close();
}

?>
