<?php
include 'dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['judul']) && isset($data['tanggal']) && isset($data['user_id'])) {
        $judul = $data['judul'];
        $tanggal = $data['tanggal'];
        $user_id = $data['user_id'];  
        $created_at = date('Y-m-d H:i:s');
        $updated_at = date('Y-m-d H:i:s');

        $query = "INSERT INTO todolist (judul, tanggal, user_id, created_at, updated_at) 
                  VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('sssss', $judul, $tanggal, $user_id, $created_at, $updated_at);

            if ($stmt->execute()) {
                $newId = $conn->insert_id;  
                echo json_encode([
                    'message' => 'Tugas berhasil ditambahkan',
                    'id' => $newId
                ]);
            } else {
                echo json_encode(['message' => 'Gagal menambahkan tugas']);
            }

            $stmt->close();
        } else {
            echo json_encode(['message' => 'Terjadi kesalahan dalam query']);
        }
    } else {
        echo json_encode(['message' => 'Data tidak lengkap']);
    }
}
?>
