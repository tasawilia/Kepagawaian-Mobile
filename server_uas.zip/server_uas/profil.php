<?php
include 'dbconnect.php';

$user_id = $_GET['user_id'] ?? $_POST['user_id'] ?? null;

if (!$user_id) {
    echo json_encode(['success' => false, 'message' => 'User ID tidak ditemukan']);
    exit;
}

function getProfile($conn, $user_id)
{
    $stmt = $conn->prepare("SELECT nama, email, password FROM user WHERE id = ?");
    $stmt->bind_param("i", $user_id); 
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

function getkaryawan($conn, $user_id)
{
    $stmt = $conn->prepare("SELECT nama, nik, alamat FROM karyawan WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

function updateProfile($conn, $user_id, $nama, $email, $password)
{
    if (empty($nama) || empty($email) || empty($password)) {
        return ['success' => false, 'message' => 'Nama, email, dan password tidak boleh kosong'];
    }

    $stmt = $conn->prepare("UPDATE user SET nama = ?, email = ?, password = ? WHERE id = ?");
    $stmt->bind_param("sssi", $nama, $email, $password, $user_id);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Profil user berhasil diupdate'];
    } else {
        return ['success' => false, 'message' => 'Gagal mengupdate profil user'];
    }
}

function updateKaryawan($conn, $user_id, $nama)
{
    if (empty($nama)) {
        return ['success' => false, 'message' => 'Nama karyawan tidak boleh kosong'];
    }

    $stmt = $conn->prepare("UPDATE karyawan SET nama = ? WHERE id = ?");
    $stmt->bind_param("si", $nama, $user_id);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Profil karyawan berhasil diupdate'];
    } else {
        return ['success' => false, 'message' => 'Gagal mengupdate profil karyawan'];
    }
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $userData = getProfile($conn, $user_id);
    $karyawanData = getkaryawan($conn, $user_id);

    if ($userData === null && $karyawanData === null) {
        echo json_encode(['success' => false, 'message' => 'Data tidak ditemukan']);
    } else {
        echo json_encode([
            'success' => true,
            'data' => [
                'user' => $userData,
                'karyawan' => $karyawanData,
            ],
        ]);
    }
} elseif ($method === 'POST') {
    $nama = $_POST['nama'] ?? null;
    $email = $_POST['email'] ?? null;
    $password = $_POST['password'] ?? null;

    $resultUser = updateProfile($conn, $user_id, $nama, $email, $password);

    $resultKaryawan = updateKaryawan($conn, $user_id, $nama);

    if ($resultUser['success'] && $resultKaryawan['success']) {
        echo json_encode(['success' => true, 'message' => 'Profil user dan karyawan berhasil diupdate']);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Gagal mengupdate profil',
            'errors' => [
                'user' => $resultUser['message'],
                'karyawan' => $resultKaryawan['message'],
            ],
        ]);
    }
}

$conn->close();
?>
