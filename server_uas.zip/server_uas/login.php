<?php
include 'dbconnect.php';

if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
} else {
    echo json_encode(['error' => 'Email atau password tidak dikirim']);
    exit();
}

try {
    $sql = "SELECT * FROM user WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        if ($password === $user['password']) {
            echo json_encode([
                'status' => 'success',
                'user_id' => $user['id'],
                'email' => $user['email'],
                'nama' => $user['nama']
            ]);
        } else {
            echo json_encode(['error' => 'Email atau password salah']);
        }
    } else {
        echo json_encode(['error' => 'Email tidak ditemukan']);
    }
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);



    echo json_encode(['error' => $e->getMessage()]);
} 