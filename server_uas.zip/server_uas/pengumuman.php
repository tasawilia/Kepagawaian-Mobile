<?php
include_once 'dbconnect.php';

$stat = $conn->prepare("SELECT id, judul, isi, tertanda FROM pengumuman;");
$stat->execute();
$stat->bind_result($id, $judul, $isi, $tertanda);

$arrayproduct = array();

while ($stat->fetch()) {

    $data = array();
    $data['id'] = $id;
    $data['judul'] = $judul;
    $data['isi'] = $isi;
    $data['tertanda'] = $tertanda;

    array_push($arrayproduct, $data);
}

echo json_encode($arrayproduct);
?>