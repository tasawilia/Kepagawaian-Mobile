<?php
include 'dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $user_id = $_GET['user_id'] ?? null;

    if ($user_id) {
        $query = "SELECT id, judul, tanggal FROM todolist WHERE user_id = ? ORDER BY tanggal ASC";
        
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param('i', $user_id);  
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $tugas = [];
                
                while ($row = $result->fetch_assoc()) {
                    $tugas[] = $row;
                }
                
                echo json_encode($tugas);  
            } else {
                echo json_encode([]); 
            }
            
            $stmt->close();
        } else {
            echo json_encode(['message' => 'Terjadi kesalahan dalam query']);
        }
    } else {
        echo json_encode(['message' => 'user_id tidak ditemukan']);
    }
}
?>
