import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'home.dart';
import 'package:http/http.dart' as http;

class Gaji extends StatefulWidget {
  const Gaji({super.key});

  @override
  State<Gaji> createState() => _GajiState();
}

class _GajiState extends State<Gaji> {
  String? selectedBulan;
  String? selectedTahun;
  List<String> bulan = [
    "Januari",
    "Februari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember"
  ];
  List<String> tahun = ["2024"];
  List<dynamic> dataGaji = [];
  String? errorMessage;

  Map<String, int> bulanMap = {
    "Januari": 1,
    "Februari": 2,
    "Maret": 3,
    "April": 4,
    "Mei": 5,
    "Juni": 6,
    "Juli": 7,
    "Agustus": 8,
    "September": 9,
    "Oktober": 10,
    "November": 11,
    "Desember": 12
  };

  String formatRupiah(int jumlahUang) {
    return jumlahUang.toString().replaceAllMapped(
          RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
          (match) => '${match.group(1)}.',
        );
  }

  Future<void> fetchdataGaji() async {
    if (selectedBulan == null || selectedTahun == null) {
      setState(() {
        errorMessage = "Silakan pilih bulan dan tahun.";
      });
      return;
    }

    final url = Uri.parse(
        'http://10.0.3.2/server_uas/gaji.php?bulan=${bulanMap[selectedBulan!]}&tahun=$selectedTahun');

    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        setState(() {
          dataGaji = jsonDecode(response.body);
          errorMessage = null;
        });
      } else {
        setState(() {
          errorMessage = "Gagal memuat data. Kode: ${response.statusCode}";
        });
      }
    } catch (error) {
      setState(() {
        errorMessage = "Terjadi kesalahan: $error";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => const HomePage(),
            ));
          },
          icon: const Icon(
            CupertinoIcons.arrow_left,
            size: 25,
            color: Colors.white,
          ),
        ),
        title: const Text(
          "Slip Gaji",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedBulan,
                    hint: const Text("Pilih Bulan"),
                    items: bulan.map((String bulan) {
                      return DropdownMenuItem<String>(
                        value: bulan,
                        child: Text(bulan),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedBulan = value;
                      });
                      fetchdataGaji();
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedTahun,
                    hint: const Text("Pilih Tahun"),
                    items: tahun.map((String tahun) {
                      return DropdownMenuItem<String>(
                        value: tahun,
                        child: Text(tahun),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedTahun = value;
                      });
                      fetchdataGaji();
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (errorMessage != null) ...[
              Text(
                errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            ] else if (selectedBulan != null && selectedTahun != null) ...[
              Expanded(
                child: ListView.builder(
                  itemCount: dataGaji.length,
                  itemBuilder: (context, index) {
                    final gaji = dataGaji[index];
                    return Card(
                      elevation: 4,
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: const [
                                    Icon(Icons.currency_exchange,
                                        color: Colors.green, size: 24),
                                    SizedBox(width: 8),
                                    Text(
                                      "Gaji Pokok",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16),
                                    ),
                                  ],
                                ),
                                Text(
                                  "Rp ${formatRupiah(int.parse(gaji['gaji_pokok']))}",
                                  style: const TextStyle(fontSize: 16),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: const [
                                    Icon(Icons.workspace_premium,
                                        color: Colors.blue, size: 24),
                                    SizedBox(width: 8),
                                    Text(
                                      "Tunjangan:",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16),
                                    ),
                                  ],
                                ),
                                Text(
                                  "Rp ${formatRupiah(int.parse(gaji['tunjangan']))}",
                                  style: const TextStyle(fontSize: 16),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: const [
                                    Icon(Icons.remove_circle,
                                        color: Colors.red, size: 24),
                                    SizedBox(width: 8),
                                    Text(
                                      "Potongan:",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16),
                                    ),
                                  ],
                                ),
                                Text(
                                  "Rp ${formatRupiah(int.parse(gaji['potongan']))}",
                                  style: const TextStyle(fontSize: 16),
                                ),
                              ],
                            ),
                            const Divider(height: 24, thickness: 1.5),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: const [
                                    Icon(Icons.account_balance_wallet,
                                        color: Colors.orange, size: 24),
                                    SizedBox(width: 8),
                                    Text(
                                      "Gaji Bersih:",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16),
                                    ),
                                  ],
                                ),
                                Text(
                                  "Rp ${formatRupiah(int.parse(gaji['gaji_bersih']))}",
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ] else ...[
              const Text("Silakan pilih bulan dan tahun."),
            ],
          ],
        ),
      ),
    );
  }
}
