import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:projectuas/cuti.dart';
import 'package:projectuas/loginscreen.dart';
import 'package:projectuas/profil.dart';

import 'homescreen.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int currentPageIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      const Homescreen(),
      const Cuti(),
      const Profil(),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        title: const Text(
          "Sistem Kepegawaian",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        leading: IconButton(
          onPressed: () async {
            bool? konfirmasiLogout = await showDialog<bool>(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  backgroundColor: Colors.green,
                  title: const Text(
                    "Konfirmasi",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  content: const Text(
                    "Apakah kamu ingin keluar?",
                    style: TextStyle(
                      color: Colors.white, 
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop(false); 
                      },
                      child: const Text(
                        "Tidak",
                        style: TextStyle(
                            color: Colors.white), 
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop(true);
                      },
                      child: const Text(
                        "Iya",
                        style: TextStyle(
                            color: Colors.white),
                      ),
                    ),
                  ],
                );
              },
            );

            if (konfirmasiLogout == true) {
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (BuildContext context) => Loginscreen(),
              ));
            }
          },
          icon: const Icon(Icons.arrow_back, color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: pages[currentPageIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.green.shade400,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.black,
        currentIndex: currentPageIndex,
        onTap: (index) {
          setState(() {
            currentPageIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.house_alt, size: 20),
            label: "Beranda",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month, size: 20),
            label: "Cuti",
          ),
          BottomNavigationBarItem(
            icon: Icon(CupertinoIcons.person_alt_circle, size: 20),
            label: "Profil",
          ),
        ],
      ),
    );
  }
}
