import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:projectuas/home.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/cupertino.dart';

class Todolist extends StatefulWidget {
  const Todolist({Key? key}) : super(key: key);

  @override
  State<Todolist> createState() => _TodolistState();
}

class _TodolistState extends State<Todolist> {
  DateTime? pilihTanggal;
  final TextEditingController _judulController = TextEditingController();
  List<dynamic> tugas = [];

  @override
  void initState() {
    super.initState();
    fetchTugas();
  }

  Future<int?> getUserIdFromSharedPreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userIdString = prefs.getString('user_id');
    if (userIdString != null) {
      return int.tryParse(userIdString);
    }
    return null;
  }

  void selectTanggal(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: pilihTanggal ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (picked != null && picked != pilihTanggal) {
      setState(() {
        pilihTanggal = picked;
      });
    }
  }

  Future<void> tambahTugas() async {
    final judul = _judulController.text;
    final tanggal = pilihTanggal?.toIso8601String().split('T')[0];

    if (judul.isEmpty || tanggal == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Judul dan tanggal harus diisi")),
      );
      return;
    }

    final userId = await getUserIdFromSharedPreferences();

    if (userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Pengguna belum login")),
      );
      return;
    }

    const String apiUrl = "http://10.0.3.2/server_uas/todolist.php";

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "judul": judul,
          "tanggal": tanggal,
          "user_id": userId,
        }),
      );

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);
        if (result['message'] == 'Tugas berhasil ditambahkan') {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              Future.delayed(const Duration(milliseconds: 1500), () {
                Navigator.of(context).pop();
              });
              return AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                backgroundColor: Colors.green,
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: const [
                    Icon(
                      CupertinoIcons.check_mark_circled_solid,
                      color: Colors.white,
                      size: 40,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Tugas berhasil ditambahkan',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              );
            },
          );
          setState(() {
            _judulController.clear();
            pilihTanggal = null;
          });
          fetchTugas();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(result['message'])),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Gagal menambahkan tugas")),
        );
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }

    setState(() {
      _judulController.clear();
      pilihTanggal = null;
    });
  }

  Future<void> fetchTugas() async {
    const String apiUrl = "http://10.0.3.2/server_uas/gettodolist.php";

    int? userId = await getUserIdFromSharedPreferences();

    if (userId == null) {
      print("User ID tidak ditemukan");
      return;
    }

    try {
      final response = await http.get(
        Uri.parse('$apiUrl?user_id=$userId'),
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        setState(() {
          tugas = jsonDecode(response.body);
        });
      } else {
        print("Gagal mendapatkan tugas: ${response.statusCode}");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  Future<void> deleteTugas(int id) async {
    final String url = 'http://10.0.3.2/server_uas/deletetodolist.php';

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'id': id.toString()}),
      );

      if (response.statusCode == 200) {
        final responseBody = json.decode(response.body);
        if (responseBody['success']) {
          setState(() {
            tugas.removeWhere((tugasItem) => tugasItem['id'] == id);
          });

          showDialog(
            context: context,
            builder: (BuildContext context) {
              Future.delayed(const Duration(milliseconds: 1500), () {
                Navigator.of(context).pop();
              });
              return AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                backgroundColor: Colors.green,
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: const [
                    Icon(
                      CupertinoIcons.check_mark_circled_solid,
                      color: Colors.white,
                      size: 40,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Tugas berhasil dihapus',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Gagal menghapus tugas")),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Gagal melakukan permintaan")),
        );
      }
    } catch (e) {
      print('Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => const HomePage(),
            ));
          },
          icon: const Icon(Icons.arrow_back, color: Colors.white),
        ),
        title: const Text(
          "To-Do List",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _judulController,
              decoration: const InputDecoration(
                labelText: "Judul Tugas",
                labelStyle: TextStyle(color: Colors.green),
                border: OutlineInputBorder(),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Text(
                    pilihTanggal == null
                        ? "Belum memilih tanggal"
                        : "Tanggal: ${pilihTanggal!.toLocal().toString().split(' ')[0]}",
                  ),
                ),
                ElevatedButton(
                  onPressed: () => selectTanggal(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                  ),
                  child: const Text("Pilih Tanggal"),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: tambahTugas,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade400,
                ),
                child: const Text("Tambah Tugas"),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: tugas.isEmpty
                  ? const Center(child: Text("Tidak ada tugas"))
                  : SingleChildScrollView(
                      child: Center(
                        child: Container(
                          width: 600,
                          child: DataTable(
                            columnSpacing: 20,
                            headingRowColor:
                                MaterialStateProperty.all(Colors.green[100]),
                            dataRowColor:
                                MaterialStateProperty.all(Colors.white),
                            columns: const [
                              DataColumn(
                                label: Text(
                                  'Judul',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                              DataColumn(
                                label: Text(
                                  'Tanggal',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                              DataColumn(
                                label: Text(
                                  'Aksi',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                            ],
                            rows: tugas
                                .map((tugas) => DataRow(cells: [
                                      DataCell(
                                        Padding(
                                          padding: const EdgeInsets.all(8),
                                          child: Text(
                                            tugas['judul'],
                                            style:
                                                const TextStyle(fontSize: 14),
                                          ),
                                        ),
                                      ),
                                      DataCell(
                                        Padding(
                                          padding: const EdgeInsets.all(8),
                                          child: Text(
                                            tugas['tanggal'],
                                            style:
                                                const TextStyle(fontSize: 14),
                                          ),
                                        ),
                                      ),
                                      DataCell(
                                        IconButton(
                                          icon: const Icon(Icons.delete,
                                              color: Colors.red),
                                          onPressed: () {
                                            deleteTugas(tugas['id']);
                                          },
                                        ),
                                      ),
                                    ]))
                                .toList(),
                          ),
                        ),
                      ),
                    ),
            )
          ],
        ),
      ),
    );
  }
}
