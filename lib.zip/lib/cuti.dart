import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Cuti extends StatefulWidget {
  const Cuti({super.key});

  @override
  State<Cuti> createState() => _CutiState();
}

class _CutiState extends State<Cuti> {
  List _tipeCutiList = [];
  String? _selectedTipeCuti;
  DateTime? _tanggalMulai;
  DateTime? _tanggalSelesai;
  String _responseMessage = "";
  bool _isLoading = false;

  List _riwayatCutiList = [];
  bool _isLoadingRiwayat = false;

  TextEditingController _tanggalMulaiController = TextEditingController();
  TextEditingController _tanggalSelesaiController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchTipeCuti();
    _fetchRiwayatCuti();
  }

  Future<void> _fetchTipeCuti() async {
    setState(() {
      _isLoading = true;
    });
    final url = Uri.parse('http://10.0.3.2/server_uas/tipecuti.php');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is List) {
          setState(() {
            _tipeCutiList = data;
            _responseMessage = "";
          });
        } else {
          setState(() {
            _responseMessage = "Format data tidak sesuai.";
          });
        }
      } else {
        setState(() {
          _responseMessage =
              "Gagal memuat data tipe cuti (${response.statusCode}).";
        });
      }
    } catch (e) {
      setState(() {
        _responseMessage = "Terjadi kesalahan: ${e.toString()}";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> pilihTanggal(BuildContext context, bool mulaiTanggal) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    setState(() {
      if (picked != null) {
        if (mulaiTanggal) {
          _tanggalMulai = picked;
          _tanggalMulaiController.text = formatDate(picked);
        } else {
          _tanggalSelesai = picked;
          _tanggalSelesaiController.text = formatDate(picked);
        }
      }
    });

    print("Tanggal Mulai: $_tanggalMulai, Tanggal Selesai: $_tanggalSelesai");
  }

  Future<void> _submitPengajuanCuti() async {
    if (_tanggalMulai != null && _tanggalSelesai != null) {
      if (_tanggalMulai!.isAfter(_tanggalSelesai!)) {
        setState(() {
          _responseMessage =
              "Tanggal mulai tidak boleh setelah tanggal selesai.";
        });
        return;
      }

      int jumlahHari = _tanggalSelesai!.difference(_tanggalMulai!).inDays + 1;

      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString('user_id');

      if (userId == null) {
        setState(() {
          _responseMessage = "User belum login!";
        });
        return;
      }

      final url = Uri.parse('http://10.0.3.2/server_uas/pengajuancuti.php');
      try {
        final response = await http.post(
          url,
          body: {
            "tipe_cuti": _selectedTipeCuti,
            "tanggal_mulai": _tanggalMulai?.toIso8601String(),
            "tanggal_selesai": _tanggalSelesai?.toIso8601String(),
            "jumlah": jumlahHari.toString(),
            "user_id": userId,
          },
        );
        if (response.statusCode == 200) {
          showDialog(
            context: context,
            builder: (context) {
              Future.delayed(const Duration(milliseconds: 1500), () {
                Navigator.of(context).pop();
              });
              return AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                backgroundColor: Colors.green,
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: const [
                    Icon(
                      CupertinoIcons.check_mark_circled_solid,
                      color: Colors.white,
                      size: 40,
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Pengajuan cuti berhasil!',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              );
            },
          );
          setState(() {
            _selectedTipeCuti = null;
            _tanggalMulai = null;
            _tanggalSelesai = null;
            _tanggalMulaiController.clear();
            _tanggalSelesaiController.clear();
          });
          _fetchRiwayatCuti();
        } else {
          setState(() {
            _responseMessage =
                "Gagal mengajukan cuti (${response.statusCode}).";
          });
        }
      } catch (e) {
        setState(() {
          _responseMessage = "Terjadi kesalahan: ${e.toString()}";
        });
      }
    }
  }

  Future<void> _fetchRiwayatCuti() async {
    setState(() {
      _isLoadingRiwayat = true;
    });

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('user_id');

    if (userId == null) {
      setState(() {
        _responseMessage = "User belum login!";
      });
      return;
    }

    final url =
        Uri.parse('http://10.0.3.2/server_uas/riwayatcuti.php?user_id=$userId');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is List) {
          setState(() {
            _riwayatCutiList = data;
          });
        } else {
          setState(() {
            _responseMessage = "Format data tidak sesuai.";
          });
        }
      } else {
        setState(() {
          _responseMessage =
              "Gagal memuat riwayat cuti (${response.statusCode}).";
        });
      }
    } catch (e) {
      setState(() {
        _responseMessage = "Terjadi kesalahan: ${e.toString()}";
      });
    } finally {
      setState(() {
        _isLoadingRiwayat = false;
      });
    }
  }

  Widget _buildRiwayatCuti() {
    if (_isLoadingRiwayat) {
      return const Center(child: CircularProgressIndicator());
    } else if (_riwayatCutiList.isEmpty) {
      return const Center(
          child:
              Text("Belum ada riwayat cuti.", style: TextStyle(fontSize: 18)));
    } else {
      return ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _riwayatCutiList.length,
        itemBuilder: (context, index) {
          final cuti = _riwayatCutiList[index];
          return Card(
            elevation: 4.0,
            margin:
                const EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15.0),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(
                    CupertinoIcons.calendar,
                    color: Colors.green,
                    size: 30,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          cuti['nama_tipe'] ?? "Tidak ada nama",
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Mulai: ${cuti['tanggal_mulai']}\nSelesai: ${cuti['tanggal_selesai']}",
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.grey,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Durasi: ${cuti['jumlah'] ?? '0'} hari",
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }
  }

  String formatDate(DateTime date) {
    return "${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Form(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        DropdownButtonFormField<String>(
                          decoration: const InputDecoration(
                            labelText: "Tipe Cuti",
                            floatingLabelStyle: TextStyle(color: Colors.green),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.green, width: 1),
                            ),
                          ),
                          value: _selectedTipeCuti,
                          items: _tipeCutiList
                              .map<DropdownMenuItem<String>>((tipe) {
                            return DropdownMenuItem<String>(
                              value: tipe["id"]?.toString() ?? "",
                              child:
                                  Text(tipe["nama_tipe"] ?? "Tidak ada nama"),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              _selectedTipeCuti = value;
                            });
                          },
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _tanggalMulaiController,
                          readOnly: true,
                          decoration: InputDecoration(
                            labelText: "Tanggal Mulai",
                            floatingLabelStyle:
                                const TextStyle(color: Colors.green),
                            hintText: _tanggalMulaiController.text.isNotEmpty
                                ? _tanggalMulaiController.text
                                : "Pilih Tanggal Mulai",
                            focusedBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.green, width: 1),
                            ),
                          ),
                          onTap: () => pilihTanggal(context, true),
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _tanggalSelesaiController,
                          readOnly: true,
                          decoration: InputDecoration(
                            labelText: "Tanggal Selesai",
                            floatingLabelStyle:
                                const TextStyle(color: Colors.green),
                            hintText: _tanggalSelesaiController.text.isNotEmpty
                                ? _tanggalSelesaiController.text
                                : "Pilih Tanggal Selesai",
                            focusedBorder: const OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.green, width: 1),
                            ),
                          ),
                          onTap: () => pilihTanggal(context, false),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () {
                            if (_selectedTipeCuti != null &&
                                _tanggalMulaiController.text.isNotEmpty &&
                                _tanggalSelesaiController.text.isNotEmpty) {
                              _submitPengajuanCuti();
                            } else {
                              setState(() {
                                _responseMessage =
                                    "Harap lengkapi semua field.";
                              });
                            }
                          },
                          style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.green),
                          ),
                          child: const Text("Ajukan Cuti"),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _responseMessage,
                          style: const TextStyle(
                            color: Colors.red,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 15),
                  Text(
                    "Riwayat Cuti",
                    style: Theme.of(context).textTheme.headline6,
                  ),
                  const SizedBox(height: 16),
                  _buildRiwayatCuti(),
                ],
              ),
            ),
    );
  }
}
