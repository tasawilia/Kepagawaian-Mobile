import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:projectuas/home.dart';

class Absensi extends StatefulWidget {
  const Absensi({super.key});

  @override
  State<Absensi> createState() => _AbsensiState();
}

class _AbsensiState extends State<Absensi> {
  DateTime? selectedDate;
  TimeOfDay? waktuMasuk;
  TimeOfDay? waktuKeluar;
  String? statusAbsen = 'Hadir';
  String? absenType;

  Future<String> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_id') ?? '0';
  }

  Future<void> simpanAbsensi() async {
    if (selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Harap pilih tanggal terlebih dahulu')),
      );
      return;
    }

    if (statusAbsen == 'Hadir') {
      if (absenType == 'Masuk' && waktuMasuk == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Harap pilih waktu masuk terlebih dahulu')),
        );
        return;
      }

      if (absenType == 'Keluar' && waktuKeluar == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Harap pilih waktu keluar terlebih dahulu')),
        );
        return;
      }
    }

    String userId = await getUserId();

    final Map<String, dynamic> data = {
      'user_id': userId,
      'tanggal': selectedDate!.toLocal().toString().split(' ')[0],
      'waktu': statusAbsen == 'Hadir'
          ? (absenType == 'Masuk'
              ? waktuMasuk!.format(context)
              : waktuKeluar!.format(context))
          : null,
      'status': statusAbsen,
      'tipe': absenType,
    };

    final String apiUrl = 'http://10.0.3.2/server_uas/absen.php';

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(data),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        String message = responseData['message'];
        showDialog(
          context: context,
          builder: (BuildContext context) {
            Future.delayed(const Duration(milliseconds: 1500), () {
              Navigator.of(context).pop();
            });
            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              backgroundColor: Colors.green,
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Icon(
                    CupertinoIcons.check_mark_circled_solid,
                    color: Colors.white,
                    size: 40,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            );
          },
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal menyimpan absensi')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Terjadi kesalahan: $e')),
      );
    }

    setState(() {
      absenType = null;
      selectedDate = null;
      waktuMasuk = null;
      waktuKeluar = null;
      statusAbsen = 'Hadir';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade400,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pushReplacement(MaterialPageRoute(
              builder: (BuildContext context) => const HomePage(),
            ));
          },
          icon: const Icon(
            CupertinoIcons.arrow_left,
            size: 25,
            color: Colors.white,
          ),
        ),
        title: const Text(
          "Absensi",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (absenType == null) ...[
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton.icon(
                      onPressed: () {
                        setState(() {
                          absenType = 'Masuk';
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(horizontal: 30),
                      ),
                      icon: const Icon(Icons.login),
                      label: const Text('Absen Masuk'),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      onPressed: () {
                        setState(() {
                          absenType = 'Keluar';
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(horizontal: 30),
                      ),
                      icon: const Icon(Icons.logout),
                      label: const Text('Absen Keluar'),
                    ),
                  ],
                ),
              ],
              if (absenType != null) ...[
                Card(
                  margin: const EdgeInsets.all(15),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Pilih Status Kehadiran:',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 10),
                        Column(
                          children: [
                            RadioListTile<String>(
                              title: const Text('Hadir'),
                              value: 'Hadir',
                              groupValue: statusAbsen,
                              onChanged: (value) {
                                setState(() {
                                  statusAbsen = value;
                                });
                              },
                              activeColor: Colors.green,
                              contentPadding: EdgeInsets.zero,
                            ),
                            RadioListTile<String>(
                              title: const Text('Sakit'),
                              value: 'Sakit',
                              groupValue: statusAbsen,
                              onChanged: (value) {
                                setState(() {
                                  statusAbsen = value;
                                });
                              },
                              activeColor: Colors.green,
                              contentPadding: EdgeInsets.zero,
                            ),
                            RadioListTile<String>(
                              title: const Text('Izin'),
                              value: 'Izin',
                              groupValue: statusAbsen,
                              onChanged: (value) {
                                setState(() {
                                  statusAbsen = value;
                                });
                              },
                              activeColor: Colors.green,
                              contentPadding: EdgeInsets.zero,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
              if (absenType != null && statusAbsen != null) ...[
                const SizedBox(height: 20),
                Card(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            selectedDate == null
                                ? 'Pilih Tanggal Absen'
                                : 'Tanggal: ${selectedDate!.toLocal()}',
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                        ElevatedButton.icon(
                          onPressed: () async {
                            final DateTime? pickedDate = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime(2000),
                              lastDate: DateTime(2101),
                            );
                            if (pickedDate != null &&
                                pickedDate != selectedDate) {
                              setState(() {
                                selectedDate = pickedDate;
                              });
                            }
                          },
                          icon: const Icon(Icons.calendar_today),
                          label: const Text('Pilih Tanggal'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                if (statusAbsen == 'Hadir' && absenType == 'Masuk') ...[
                  Card(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              waktuMasuk == null
                                  ? 'Pilih Waktu Masuk'
                                  : 'Waktu Masuk: ${waktuMasuk!.format(context)}',
                              style: const TextStyle(fontSize: 16),
                            ),
                          ),
                          ElevatedButton.icon(
                            onPressed: () async {
                              final TimeOfDay? pickedTime =
                                  await showTimePicker(
                                context: context,
                                initialTime: (absenType == 'Masuk'
                                        ? waktuMasuk
                                        : waktuKeluar) ??
                                    TimeOfDay.now(),
                              );
                              if (pickedTime != null) {
                                setState(() {
                                  if (absenType == 'Masuk') {
                                    waktuMasuk = pickedTime;
                                  } else {
                                    waktuKeluar = pickedTime;
                                  }
                                });
                              }
                            },
                            icon: const Icon(Icons.access_time),
                            label: const Text('Pilih Waktu'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ] else if (statusAbsen == 'Hadir' && absenType == 'Keluar') ...[
                  Card(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              waktuKeluar == null
                                  ? 'Pilih Waktu Keluar'
                                  : 'Waktu Keluar: ${waktuKeluar!.format(context)}',
                              style: const TextStyle(fontSize: 16),
                            ),
                          ),
                          ElevatedButton.icon(
                            onPressed: () async {
                              final TimeOfDay? pickedTime =
                                  await showTimePicker(
                                context: context,
                                initialTime: (absenType == 'Keluar'
                                        ? waktuKeluar
                                        : waktuMasuk) ??
                                    TimeOfDay.now(),
                              );
                              if (pickedTime != null) {
                                setState(() {
                                  if (absenType == 'Keluar') {
                                    waktuKeluar = pickedTime;
                                  } else {
                                    waktuMasuk = pickedTime;
                                  }
                                });
                              }
                            },
                            icon: const Icon(Icons.access_time),
                            label: const Text('Pilih Waktu'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 20),
                Center(
                  child: ElevatedButton.icon(
                    onPressed: simpanAbsensi,
                    icon: const Icon(Icons.save),
                    label: const Text('Simpan Absensi'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
